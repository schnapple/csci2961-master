remove_trailing_comma <- function(x) sub(",$", "", x)
